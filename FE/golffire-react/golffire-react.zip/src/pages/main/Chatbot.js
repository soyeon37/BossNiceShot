import React from "react";
import ChatBox from "./chatbot/ChatBox";

function Chatbot() {
  return (
    <div className="Chatbot">
      <ChatBox />
    </div>
  );
}

export default Chatbot;
