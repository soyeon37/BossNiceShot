import React from "react";


function Solution() {
  return (
    <div id="Solution" style={{height:"800px"}}>
      <h1 style={{fontSize:"50px",padding:"20%"}}>
        Solution
      </h1>
    </div>
  );
};

export default Solution;
