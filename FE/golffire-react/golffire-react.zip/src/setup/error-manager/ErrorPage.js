import React from "react";

function ErrorPage() {
  return (
    <div>
      오류가 발생했습니다.
      <a href="/">
        <button>홈 화면으로 돌아가기</button>
      </a>
    </div>
  );
}

export default ErrorPage;
